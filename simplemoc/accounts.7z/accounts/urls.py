from django.urls import include, re_path
from django.contrib.auth import views
from simplemoc.accounts import views as views_accounts

app_name='accounts'

urlpatterns = [
    re_path(r'^entrar/$', views.LoginView.as_view(template_name ='accounts/login.html'), name='login'),    
    re_path(r'^cadastre-se/$', views_accounts.register, name='register'),      
]